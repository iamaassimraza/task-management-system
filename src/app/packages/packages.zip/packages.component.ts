import { Component, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PackageService } from '../Apis/package.service';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { OtherService } from '../Apis/other.service';
@Component({
  selector: 'app-packages',
  templateUrl: './packages.component.html',
  styleUrls: ['./packages.component.css'],
})
export class PackagesComponent {
  // Variables
  hide = true;
  toastr: any;
  btn: string = 'Save';
  totalFee = 0;

  // Arrays
  allPackage: any[] = [];
  allState: any[] = [];
  allDepartment: any[] = [];
  allServices: any[] = [];
  addOns: any[] = [];
  allCountries: any[] = [];
  country: any;
  cloudUpload = false;
  display = 'none';
  fee: string;
  constructor(
    private serPackages: PackageService,
    private toast: ToastrService,
    private otherSer: OtherService
  ) {}
  packageForm = new FormGroup({
    tbl_pkg_id: new FormControl(null),
    pkg_title: new FormControl('', [Validators.required]),
    pkg_fee: new FormControl(''),
    pkg_detail: new FormControl('', [Validators.required]),
    pkg_includes: new FormControl('', [Validators.required]),
    pkg_add_Ons: new FormControl(null),
    pkg_services: new FormControl(''),
    country: new FormControl('', [Validators.required]),
    // pkg_title: d.pkg_Title.value,
    // pkg_fee: d.pkg_Fee.value,
    // pkg_includes: d.pkg_Includes.value,
    // pkg_detail: d.pkg_Detail.value,
    // pkg_services:this.addOns,
    // country: d.counrty.value,
  });
  ngOnInit(): void {
    this.getAllPackages();
    this.getAllServices();
    console.log('MY FORM', this.packageForm);
    this.getAllCountries();
  }
  getAllCountries() {
    this.otherSer.getAllCountries().subscribe((res) => {
      console.log('country', res);
      this.allCountries = [];
      this.allCountries = res;
    });
  }

  add_addon(i: any, Serid: number, e: any) {
    console.log('E', e);
    if (e.target.checked === true) {
      this.totalFee = this.totalFee + Number(i);
      this.addOns.push(Serid);
    } else if (e.target.checked === false) {
      this.totalFee = this.totalFee - Number(i);
      this.addOns.splice(this.addOns.indexOf(Serid), 1);
    }
    console.log('Add ons', this.addOns);
  }
  getAllPackages() {
    // this.btn='Save'
    // this.btn='Update'
    this.serPackages.getAllPackages().subscribe((res) => {
      console.log('PACKAGEXS', res);
      this.allPackage = [];
      this.allPackage = res.packages;
      this.allPackage.reverse()

      console.log(this.allPackage, 'ss');
    });
  }
  getAllServices() {
    this.serPackages.getAllServices().subscribe((res) => {
      console.log('Services', res);
      this.allServices = [];
      this.allServices = res;
    });
  }
  changeCountry(event: any) {
    console.log('ssssssssssssssss', event);
    this.country = event;

    // console.log('asasasd',this.packageForm.controls['counrty'].value);
  }
  submit(d: any) {
    // let d =this.packageForm.controls;
    console.log('form values', this.packageForm.value);
    // this.packageForm.controls['counrty'].setValue(this.country)
    if (this.packageForm.invalid) {
      this.packageForm.markAllAsTouched();

      this.toast.error('Please Fill All Information');
      return;
    }
    console.log('this faorm', this.packageForm.value);
    // const pkgIncludes = this.pkgIncludesControl.value.split(',');
    // const pkgIncludes = this.packageForm.controls['pkg_includes'].setValue()
    // console.log(pkgIncludes);
    let data = {
      pkg_title: this.packageForm.controls['pkg_title'].value,
      pkg_fee: this.totalFee,
      pkg_includes: this.packageForm.controls['pkg_includes'].value,
      pkg_detail: this.packageForm.controls['pkg_detail'].value,
      pkg_services: this.addOns,
      country:this.packageForm.controls['country'].value,
      // pkg_add_Ons: this.addOns,
    };
    // console.log(data);
    if (this.btn == 'Save') {
      this.serPackages.addPackages(data).subscribe((res) => {
        console.log(res);

        this.toast.success('Saved', 'Congratulations!');
        this.getAllPackages();
      });
    } else if (this.btn == 'Update') {
      // let data = {
      //   tbl_pkg_id:this.resId,
      //   pkg_title: this.packageForm.controls['pkg_title'].value,
      // pkg_fee:this.packageForm.controls['pkg_fee'].value,
      // pkg_includes: this.packageForm.controls['pkg_includes'].value,
      // pkg_detail:this.packageForm.controls['pkg_detail'].value,
      // pkg_services:this.addOns,
      // country:this.country,
      // // pkg_add_Ons: this.addOns,
      // };
      let form = this.packageForm.value;

      console.log(data, 'data when update here ');

      this.serPackages.updatePackageById(form).subscribe((res) => {
        console.log(res);
        this.toast.success('Updated', 'Congratulations !');
        this.getAllPackages();
      });
    }
  }
  edit(id: any) {
    this.btn = 'Update';
    let data = {
      tbl_pkg_id: id,
    };
    console.log('id', id);

    this.serPackages.getPackageById(data).subscribe((res) => {
      console.log('response', res);
      console.log('sss', res.package_services);

      this.packageForm.patchValue({
        tbl_pkg_id: res.package.tbl_pkg_id,
        pkg_title: res.package.pkg_title,
        pkg_fee: res.package.pkg_fee,
        pkg_includes: res.package.pkg_includes,
        pkg_detail: res.package.pkg_detail,
        pkg_services: res.package.package_services,
        country: res.package.country,
        pkg_add_Ons:res.package.package_services
        
      });
      console.log(this.packageForm.value, 'value after patch');
    });
  }

  deletePackage(id: any) {
    let data = {
      tbl_pkg_id: id,
    };

    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        this.serPackages.deletePackage(data).subscribe((res) => {
          console.log(res);
          if (res == 'success') {
            // Swal.fire({
            //   position: 'center',
            //   icon: 'success',
            //   title: 'record deleted.',
            //   showConfirmButton: false,
            //   timer: 1500,
            // });
            this.toast.error('Record Deleted');
            this.getAllPackages();
          }
        });
      } else if (result.isDenied) {
        Swal.fire('Changes are not saved', '', 'info');
      }
    });
  }
  openModal() {
    this.display = 'block';
  }
  clearbox() {
    this.cloudUpload = true;
    this.btn = 'Save';
    this.totalFee = 0;
   
    this.addOns = []
    this.packageForm.reset();
    this.packageForm.patchValue({
       pkg_title: null,
      pkg_fee: null,
      pkg_includes: null,
      pkg_detail: null,
      pkg_services: null,
      country: null,
      pkg_add_Ons:null
    });
    this.openModal();
  }
}
