import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { OrderService } from '../Apis/order.service';
import { OtherService } from '../Apis/other.service';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ToastrService } from 'ngx-toastr';
import { TodoService } from '../Apis/todo.service';
import { EmployeeService } from '../Apis/employee.service';

import { ServicesService } from '../Apis/services.service';
import { MatTableModule } from '@angular/material/table';
import { from } from 'rxjs';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class ServicesComponent implements OnInit {

  // Arrays
  allOrders: any[] = [];
  filteredOrders: any[] = [];
  allEmployee: any[] = [];
  allStatus: any[] = [];
  allServices: any[] = [];
  filteredServices: any[] = [];

  // Variables
  empID: any;
  btn: any = 'Submit';
  assignerID: any
  assignerName: any;
  orderID: any;
  p: number = 1;
  totallength: number = 0;
  hidepagination = true;

  imgBasePath: string;
  expandContent = false;
  type: any = '';
  hidepaginatoin = true;
  no_record = false;
  initial: any;
  display = 'none';

  constructor(private ser: ServicesService, private otherSer: OtherService, private orderSer: OrderService, private employeeSer: EmployeeService, private toast: ToastrService) {
    this.imgBasePath = this.otherSer.imgUrl;
  }
  serviceForm = new FormGroup(
    {
      service_title: new FormControl(null, [Validators.required]),
      service_detail: new FormControl(null, [Validators.required]),
      service_fee: new FormControl(null, [Validators.required]),
      business_days: new FormControl(null, [Validators.required]),
      service_status: new FormControl(null, [Validators.required]),
      tbl_service_id: new FormControl(null)
    }
  )
  ngOnInit(): void {
    this.getAllServices();
  }
  getAllServices() {
    this.ser.getAllServices().subscribe(res => {
      console.log('Order', res);
      this.allServices = res;
      this.filteredServices = res;
    })
  }

  filterServices(val: any) {
    if (val == 'all') {
      this.filteredServices = this.allServices;
      return;
    }
    return this.filteredServices = this.allServices.filter(service => service.service_status === val);
  }
  edit(id: any) {
    console.log(id)

    this.btn = 'Update';
    let data = {
      tbl_service_id: id

    }
    console.log(data)
    this.ser.getServiceById(data).subscribe(res => {
      console.log(res);
      if(res[0].service_title === 'serviceMashrBusinessAddress'){
        res[0].service_title = 'Business Address'
      }if(res[0].service_title === 'serviceMashrRegisteredAgent'){
        res[0].service_title = 'Registered Agent'
      }
      if(res[0].service_title === 'serviceMashrCompanyFormation'){
        res[0].service_title = 'LLC'
      }
      if(res[0].service_title === 'serviceMashrEINwithSSN'){
        res[0].service_title = 'EIN'
      }
      if(res[0].service_title === 'serviceMashrEINwithoutSSN'){
        res[0].service_title = 'EIN without SSN'
      }
      if(res[0].service_title === 'serviceMashrBankAccount'){
        res[0].service_title = 'Bank'
      }
      if(res[0].service_title === 'serviceMashrAmazon'){
        res[0].service_title = 'Amazon'
      }
      this.serviceForm.patchValue({
        service_title: res[0].service_title,
        service_detail: res[0].service_detail,
        service_fee: res[0].service_fee,
        business_days: res[0].business_days,
        service_status:res[0].service_status,
        tbl_service_id: res[0].tbl_service_id
      })
      // console.log(this.employeeForm.controls.imageName.value)
      console.log(this.serviceForm)
    })
  }

  submit(e: any) {

    console.log('My form inside submit', this.serviceForm.value)
    if (this.serviceForm.invalid) {
      this.serviceForm.markAllAsTouched();
      this.toast.error('Please Fill All Information');
      return
    }
    let data = {
       service_title: e.service_title,
        service_detail: e.service_detail,
        service_fee: e.service_fee,
        business_days: e.business_days,
        tbl_service_id: e.tbl_service_id,
        service_status : e.service_status
      }




   if (this.btn == 'Update') {
      console.log(data, '..')
      this.ser.updateServiceById(data).subscribe(res => {
        console.log(res);
        if (res == 'serviceUpdate') {
          this.toast.success('Updated Successfully!');
          this.getAllServices()      
        }
        else {
          this.toast.error('No Changes Are Saved');
        }
      })
    }
  }


  getClassOf(val: any) {
    if (val == 'active') {
      return 'label label-success';
    } else if (val == 'blocked') {
      return 'label label-danger';
    }
    else {
      return 'label label-info'
    }
  }
	actions(e: any, oID:number) {
    let val = e.target.value
		console.log('VAL-----',val)
		let val1 = oID;
		console.log('VAL1-----',val1)
    
		if (val == 'active') {
			let data = {
        tbl_service_id:oID,
        service_status:e.target.value
      }
      console.log(data, "data here");
      this.ser.updateServiceStatusById(data).subscribe(res => {
        console.log(res, "response here")
        if (res == 'serviceStatusUpdate') {
          this.toast.success('Updated Successfully!');
          this.getAllServices()      
        }
        else {
          this.toast.error('No Changes Are Saved');
        }

      })
      
		}
		else if (val == 'blocked') {
      let data = {
        tbl_service_id:oID,
        service_status:e.target.value
      }
      console.log(data, "data here");
      this.ser.updateServiceStatusById(data).subscribe(res => {
        console.log(res, "response here")
        if (res == 'serviceStatusUpdate') {
          this.toast.success('Updated Successfully!');
          this.getAllServices()      
        }
        else {
          this.toast.error('No Changes Are Saved');
        }

      })
      
		}
	}
  // onClick(e: any, status:string) {
  //   console.log(e,"target value");
  //   let service_status = status === 'Active' ? 1 : 0;
  //   console.log(service_status);
  //   debugger;
  //   let data = {
  //    tbl_service_id : e.tbl_service_id,
  //    service_status : e.service_status
  //    }
     
  //   debugger;
  //   this.ser.updateServiceStatusById(data).subscribe(res => {
  //     console.log("data here..", res)
  //     if(res == 'serviceStatusUpdate'){
  //       this.toast.success('Updated Successfully!');
  //       this.getAllServices()   
  //     }
  //     else{
  //       this.toast.error('No Changes Are Saved');
  //     }
  //   })
   
  // }

}
